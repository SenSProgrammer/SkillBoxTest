import { PrismaClient } from "@prisma/client"; const p=new PrismaClient();
async function main(){ const b=await p.book.upsert({where:{slug:"consciology"},create:{slug:"consciology",title:"Сознание как информационная система"},update:{}});
await p.thesis.create({data:{bookId:b.id,slug:"ths-2025-001",language:"ru",confession:"scientific",textHtml:"<h2>Определение</h2><p>Сознание как информационная система...</p>",status:"PUBLISHED"}}); }
main().finally(()=>p.$disconnect());
