import { FastifyPluginAsync } from "fastify"; import { prisma } from "../prisma"; import { authGuard, roleGuard } from "../auth"; import puppeteer from "puppeteer"; import { EpubCreator } from "epub-gen-memory"; import { putExport } from "../s3";
const plugin:FastifyPluginAsync=async(app)=>{
  app.addHook("preHandler", async (req,reply)=>authGuard(req,reply));
  app.addHook("preHandler", async (req,reply)=>roleGuard(["EDITOR","ADMIN"])(req,reply));
  app.get("/modqueue/comments", async ()=> prisma.comment.findMany({ where:{ moderationStatus:"PENDING"}, orderBy:{createdAt:"asc"}, include:{thesis:true,author:true} }));
  app.post("/comments/:id/moderate", async (req)=>{ const {id}=req.params as any; const {action}=req.body as any; return prisma.comment.update({where:{id},data:{moderationStatus: action==="APPROVE"?"APPROVED":"REJECTED"}}); });
  app.post("/export", async (req,reply)=>{
    const { scope, fmt, title } = req.body as any;
    const items = scope?.thesisSlugs?.length ? await prisma.thesis.findMany({ where:{ slug:{ in: scope.thesisSlugs } }}) :
      await (async ()=>{ const b=await prisma.book.findUnique({where:{slug:scope?.bookSlug||""}}); if(!b) return []; return prisma.thesis.findMany({ where:{ bookId:b.id, status:"PUBLISHED" }, orderBy:{createdAt:"asc"} }); })();
    if (!items.length) return reply.code(404).send({error:"No content"});
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title||"LiveBook Export"}</title>
<style>body{font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:24px}.cover{page-break-after:always;text-align:center;margin-top:25vh}.cover h1{font-size:36px}.cover .meta{color:#666}header,footer{font-size:10px;color:#666}h1,h2{page-break-after:avoid}.toc h1{font-size:20px}.toc a{text-decoration:none;color:#333}article{margin:16px 0}</style>
</head><body>
<section class="cover"><h1>${title||"LiveBook Export"}</h1><div class="meta">Сгенерировано LiveBook</div></section>
<section class="toc"><h1>Оглавление</h1><ol>${items.map((t:any,i:number)=>`<li><a href=#sec-${i}>${t.slug}</a></li>`).join("")}</ol></section>
${items.map((t:any,i:number)=>`<article id=sec-${i}><h2>${t.slug}</h2>${t.textHtml||""}</article>`).join("\n<hr/>\n")}
</body></html>`;
    if (fmt==="html") return reply.type("text/html").send(html);
    if (fmt==="pdf"){
      const b=await puppeteer.launch({ headless:"new" }); const p=await b.newPage(); await p.setContent(html,{waitUntil:"networkidle0"});
      const pdf=await p.pdf({ format:"A4", margin:{top:"60px",bottom:"60px",left:"20px",right:"20px"}, printBackground:true, displayHeaderFooter:true,
        headerTemplate:`<div style="font-size:10px;width:100%;text-align:center;">${title||"LiveBook"} — <span class="date"></span></div>`,
        footerTemplate:`<div style="font-size:10px;width:100%;text-align:center;"><span class="pageNumber"></span>/<span class="totalPages"></span></div>`
      }); await b.close();
      if ((req.query as any)?.store==='1'){ const url=await putExport(`exports/export.pdf`, pdf, "application/pdf"); return {url}; }
      reply.header("Content-Disposition","attachment; filename=livebook_export.pdf"); return reply.type("application/pdf").send(pdf);
    }
    if (fmt==="epub"){
      const creator=new EpubCreator({ title: title||"LiveBook Export", author:"LiveBook", content: items.map((t:any)=>({title:t.slug,data:t.textHtml||""})) });
      const buf=await creator.getBuffer();
      if ((req.query as any)?.store==='1'){ const url=await putExport(`exports/export.epub`, buf as Buffer, "application/epub+zip"); return {url}; }
      reply.header("Content-Disposition","attachment; filename=livebook_export.epub"); return reply.type("application/epub+zip").send(buf);
    }
  });
};
export default plugin;
