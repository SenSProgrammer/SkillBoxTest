document.getElementById('send').addEventListener('click', async () => {
  const text = document.getElementById('text').value.trim();
  if (!text) return;
  const apiBase = localStorage.getItem('apiBase') || 'http://localhost:8080';
  const res = await fetch(`${apiBase}/api/comments/ingest`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  const data = await res.json();
  alert('Создано: ' + JSON.stringify(data));
});
